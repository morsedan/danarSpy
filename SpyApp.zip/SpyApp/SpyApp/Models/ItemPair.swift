//
//  ItemPair.swift
//  SpyApp
//
//  Created by morse on 2/2/20.
//  Copyright © 2020 morse. All rights reserved.
//

import Foundation

struct ItemPair {
    let spyItem: String
    let defenderItem: String
}
